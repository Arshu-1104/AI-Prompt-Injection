"use strict";
(() => {
  // src/background.ts
  function withTimeout(ms) {
    const controller = new AbortController();
    const timer = self.setTimeout(() => controller.abort(), ms);
    return { signal: controller.signal, cancel: () => self.clearTimeout(timer) };
  }
  async function handlePredict(text) {
    const config = await chrome.storage.sync.get({ enabled: true, endpoint: "", apiKey: "" });
    if (config.enabled === false || !config.endpoint || !config.apiKey) return { status: "unconfigured" };
    const timeout = withTimeout(3e3);
    try {
      const response = await fetch(`${config.endpoint.replace(/\/$/, "")}/predict`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${config.apiKey}` },
        body: JSON.stringify({ text, model: "classical" }),
        signal: timeout.signal
      });
      timeout.cancel();
      if (!response.ok) return { status: "error", message: `HTTP ${response.status}` };
      const data = await response.json();
      await chrome.storage.local.set({ lastResult: data });
      return { status: "ok", label: data.label, confidence: data.confidence, risk_score: data.risk_score, attack_patterns: data.attack_patterns };
    } catch (error) {
      timeout.cancel();
      if (error instanceof DOMException && error.name === "AbortError") return { status: "timeout" };
      return { status: "error", message: error instanceof Error ? error.message : "Unknown error" };
    }
  }
  async function handleHealth(endpoint) {
    const timeout = withTimeout(15e3);
    try {
      const response = await fetch(`${endpoint.replace(/\/$/, "")}/health`, { signal: timeout.signal });
      timeout.cancel();
      return response.ok ? { status: "ok" } : { status: "error", message: `HTTP ${response.status}` };
    } catch (error) {
      timeout.cancel();
      if (error instanceof DOMException && error.name === "AbortError") return { status: "timeout" };
      return { status: "error", message: error instanceof Error ? error.message : "Unknown error" };
    }
  }
  chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
    if (request.type === "predict") {
      void handlePredict(request.payload.text).then(sendResponse);
      return true;
    }
    if (request.type === "health_check") {
      void handleHealth(request.payload.endpoint).then(sendResponse);
      return true;
    }
    return false;
  });
})();
