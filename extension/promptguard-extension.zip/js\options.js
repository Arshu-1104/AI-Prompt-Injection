"use strict";
(() => {
  // src/options.ts
  var endpoint = document.getElementById("endpoint");
  var apiKey = document.getElementById("apiKey");
  var enabled = document.getElementById("enabled");
  var testBtn = document.getElementById("testBtn");
  var saveBtn = document.getElementById("saveBtn");
  var testStatus = document.getElementById("testStatus");
  var msg = document.getElementById("msg");
  void chrome.storage.sync.get({ endpoint: "", apiKey: "", enabled: true }).then((data) => {
    endpoint.value = data.endpoint ?? "";
    apiKey.value = data.apiKey ?? "";
    enabled.checked = data.enabled !== false;
  });
  testBtn.addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "health_check", payload: { endpoint: endpoint.value } }, (response) => {
      testStatus.textContent = response.status === "ok" ? "Connected OK" : `Failed: ${response.message ?? response.status}`;
    });
  });
  saveBtn.addEventListener("click", () => {
    try {
      const url = new URL(endpoint.value);
      void chrome.permissions.request({ origins: [`${url.origin}/*`] }, (granted) => {
        if (!granted) {
          msg.textContent = "Permission denied";
          return;
        }
        void chrome.storage.sync.set({ endpoint: endpoint.value, apiKey: apiKey.value, enabled: enabled.checked }).then(() => {
          msg.textContent = "Saved";
        });
      });
    } catch {
      msg.textContent = "Invalid URL";
    }
  });
})();
