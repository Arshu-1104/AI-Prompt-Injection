"use strict";
(() => {
  // src/popup.ts
  var statusEl = document.getElementById("status");
  var lastResult = document.getElementById("lastResult");
  var toggle = document.getElementById("enableToggle");
  var settingsLink = document.getElementById("settingsLink");
  void chrome.storage.sync.get({ enabled: true, endpoint: "" }).then((data) => {
    toggle.checked = data.enabled !== false;
    statusEl.textContent = data.endpoint ? toggle.checked ? "Active" : "Disabled" : "Configure in Settings";
  });
  void chrome.storage.local.get({ lastResult: null }).then((data) => {
    if (data.lastResult?.label) lastResult.textContent = `${data.lastResult.label} - risk ${data.lastResult.risk_score?.toFixed(1) ?? "n/a"}`;
  });
  toggle.addEventListener("change", () => {
    void chrome.storage.sync.set({ enabled: toggle.checked });
  });
  settingsLink.addEventListener("click", (event) => {
    event.preventDefault();
    chrome.runtime.openOptionsPage();
  });
})();
